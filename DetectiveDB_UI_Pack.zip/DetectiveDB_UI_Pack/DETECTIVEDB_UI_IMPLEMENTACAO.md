# DetectiveDB — Guia completo de implementação da interface

> **DOCUMENTO PARA AGENTE DE CÓDIGO (Copilot, Cursor, Codex, Claude Code, etc.)**  
> **Objetivo:** reproduzir, de forma funcional e responsiva, a UI **simplificada** do DetectiveDB representada em `reference/ui_reference_clean.png`. Use os PNGs de `assets/` como recursos visuais. O projeto subjacente é de **Engenharia de Dados com dbt Core + DuckDB**, com frontend **Streamlit**.  
> **IMPORTANTE:** este arquivo é uma especificação de implementação. Não entregue uma imagem estática do dashboard; construa componentes interativos que leem informações reais do pipeline. **Não copie os números, personagens, datas ou alegações da imagem como dados de produção.**

---

## 0. Resumo executivo e ordem de prioridades

Construa uma aplicação chamada **DetectiveDB**: uma interface investigativa minimalista, dark/noir, com navegação lateral, resumo de caso, quatro cartões de métricas, tabela de suspeitos, feed de evidências, resumo de contradições e indicadores reais dos testes dbt.

**Prioridades, em ordem:**

1. **Funcionamento:** abrir a aplicação sem erro com `streamlit run app/streamlit_app.py`.
2. **Integração:** consumir os modelos dbt existentes no DuckDB e os resultados reais dos testes dbt; mensagens úteis quando ainda não há dados.
3. **Fidelidade visual:** manter a composição geral da imagem de referência, mas com espaço negativo e sem painéis extras na home.
4. **Navegação:** fazer os itens da sidebar e as ações principais funcionarem.
5. **Responsividade/acessibilidade:** preservar legibilidade em notebook, desktop e tela pequena.
6. **Qualidade:** código modular, tipado quando possível, testável e sem credenciais ou APIs externas desnecessárias.

**Não fazer:** criar aplicação em React, inventar backend FastAPI, adicionar gráficos e animações por toda a tela, inserir estatísticas hardcoded, simular execução de dbt, usar o PNG da referência como background da página inteira ou exibir um score de suspeita como probabilidade de culpa.

---

## 1. Relação com o projeto de Engenharia de Dados

O DetectiveDB nasce de um desafio de **transformação modular e qualidade**:

- Carregar CSVs fictícios de suspeitos, evidências, câmeras, depoimentos e locais.
- Ingerir os dados no DuckDB (`raw`).
- Transformar os dados via modelos SQL do dbt (`staging` e `marts`).
- Validar a qualidade com `unique`, `not_null`, `relationships`, `accepted_values` e testes SQL personalizados.
- Injetar um dado propositalmente errado, executar os testes, registrar a falha, corrigir e executar novamente.
- Exibir na UI **resultados reais** dessas transformações e validações.

O arquivo `docs/DetectiveDB_ESPECIFICACAO.md`, incluído neste pacote, explica os requisitos do pipeline. **Leia-o antes de alterar nomes de modelos, colunas, caminhos ou estrutura do backend.** Este guia descreve especificamente a camada de apresentação.

A história padrão do projeto original é **Caso 001 — O Relógio Parado**. A screenshot é apenas uma inspiração estética e usa outro caso ilustrativo (`C-1047 — Riverside Homicide`). **Não trocar a história do projeto sem necessidade.** O cabeçalho deve usar o caso real/sintético configurado no repositório.

---

## 2. Material entregue no ZIP

Estrutura do pacote:

```text
DetectiveDB_UI_Pack/
├── DETECTIVEDB_UI_IMPLEMENTACAO.md        <- este guia detalhado
├── LEIA_PRIMEIRO.md                        <- instruções rápidas
├── docs/
│   └── DetectiveDB_ESPECIFICACAO.md        <- requisitos do projeto original
├── reference/
│   └── ui_reference_clean.png              <- screenshot principal (REFERÊNCIA, não usar como tela)
├── assets/
│   ├── assets_manifest.json               <- manifesto de arquivos e dimensões
│   ├── branding/
│   │   └── detective_mark.png              <- símbolo decorativo da marca
│   ├── backgrounds/
│   │   ├── sidebar_scene.png               <- cena investigativa na sidebar
│   │   └── header_city.png                 <- paisagem urbana discreta no cabeçalho
│   └── evidence/
│       ├── camera_footage.png              <- miniatura de câmera
│       ├── digital_evidence.png            <- miniatura de telefone/documento digital
│       └── physical_evidence.png           <- miniatura de evidência física
└── app/
    └── styles/
        └── detectivedb_tokens.css          <- variáveis CSS de referência
```

### 2.1 Instruções de uso dos PNGs

| Arquivo | Onde aparecer | Como renderizar | Obrigatório? |
|---|---|---|---|
| `reference/ui_reference_clean.png` | Documentação/README | Apenas referência visual | Sim, no processo de desenvolvimento |
| `assets/branding/detective_mark.png` | Topo da sidebar | `object-fit: contain`, aprox. 64–76 px de largura | Sim |
| `assets/backgrounds/sidebar_scene.png` | Base da sidebar | `object-fit: cover`, gradiente escuro por cima | Sim em desktop; pode ocultar no mobile |
| `assets/backgrounds/header_city.png` | Parte superior do conteúdo | Fundo opcional com opacidade baixa | Opcional |
| `assets/evidence/camera_footage.png` | Feed de evidências tipo câmera | Miniatura aprox. 105 × 64 px | Sim, quando aplicável |
| `assets/evidence/digital_evidence.png` | Feed de evidências digitais | Miniatura aprox. 105 × 64 px | Sim, quando aplicável |
| `assets/evidence/physical_evidence.png` | Feed de evidências físicas | Miniatura aprox. 105 × 64 px | Sim, quando aplicável |

**Observações importantes sobre os recursos:**

- Os PNGs são **recortes de uma imagem de referência gerada por IA**. São ilustrações fictícias, não fotos de provas verdadeiras.
- Há pequenos detalhes visuais embutidos nos recortes (por exemplo, um símbolo de reprodução na miniatura de câmera). **Não construir um botão de vídeo fictício por cima.** Só oferecer reprodução se existir um vídeo de verdade.
- Se não houver imagem correspondente ao tipo de evidência, renderizar um placeholder neutro feito com CSS e ícone, nunca um caminho de imagem quebrado.
- Ícones de navegação, tabela, busca e métricas devem ser preferencialmente **SVG/Lucide ou ícones vetoriais consistentes**, não recortes da screenshot.
- Não exibir a imagem completa como se fosse a interface: ela serve apenas de modelo para recriar os componentes.

### 2.2 Caminhos no repositório

Ao integrar ao projeto original, usar estas pastas:

```text
<raiz-do-repositorio>/
├── assets/                       <- copiar a pasta assets/ do pacote
├── app/
│   ├── streamlit_app.py
│   ├── components/
│   ├── services/
│   └── styles/
│       └── detectivedb_tokens.css
├── detective_dbt/
│   └── target/
│       └── run_results.json      <- gerado pelo dbt, NÃO versionar como mock
└── data/
    └── detectivedb.duckdb        <- gerado pelo pipeline
```

O caminho de `assets/` deve ser resolvido pelo diretório do repositório, **nunca pelo diretório corrente de onde o Streamlit foi iniciado**.

---

## 3. Direção de arte: dark/noir minimalista

### 3.1 Personalidade visual

A interface deve parecer uma **ferramenta real de inteligência e análise de dados** com tempero de investigação criminal. O resultado esperado é limpo, sério, fácil de ler, não uma tela de filme de hackers.

**Palavras-chave:** noir, moderno, silencioso, preciso, investigativo, contraste, clareza, consistência.

**Evitar:** muitos gradientes, bordas neon, excesso de vermelho, sombras muito fortes, várias linhas divisórias, ícones enormes, painéis com tabelas minúsculas, efeitos de chuva sobre o conteúdo, animações chamativas.

### 3.2 Paleta de cores

Os valores abaixo são tokens iniciais, ajustáveis levemente para aproximar a referência.

| Token | Cor | Aplicação |
|---|---|---|
| `--bg-app` | `#080D12` | Fundo geral |
| `--bg-sidebar` | `#0B0D11` | Barra lateral |
| `--bg-panel` | `#111820` | Cards principais |
| `--bg-panel-alt` | `#151D26` | Cabeçalhos de tabelas/áreas internas |
| `--bg-hover` | `#1C2630` | Hover em linhas e itens |
| `--border` | `#29333E` | Bordas discretas |
| `--text-primary` | `#F4F7FA` | Títulos e números |
| `--text-secondary` | `#AFBBC7` | Texto auxiliar |
| `--text-muted` | `#738190` | Descrições menos importantes |
| `--accent-red` | `#F05255` | Contradições e alertas |
| `--accent-amber` | `#E9AA49` | Evidências e avisos |
| `--accent-blue` | `#5AABE8` | Qualidade e links |
| `--accent-green` | `#3DCC78` | Sucesso de testes |

**Uso semântico de cor:** vermelho = possível problema/contradição; amarelo = parcial/pendente; verde = teste aprovado ou dado verificado; azul = neutro/analítico. Não usar verde para indicar inocência.

### 3.3 Tipografia

- Família: `Inter`, `Segoe UI`, `Arial`, sans-serif; garantir fallback local.
- Nome da aplicação: 25–28 px, semibold/bold.
- Título da página: 30–34 px, bold, altura de linha ~1.15.
- Título dos cards: 17–20 px, semibold.
- Números de KPI: 34–40 px, bold, alinhamento consistente.
- Labels de métricas: 13–15 px.
- Texto e linhas das tabelas: 13–15 px.
- Legendas, timestamps e chips: 11–13 px.
- Evitar corpo abaixo de 12 px em desktop; no mobile preservar leitura.

### 3.4 Espaçamento e formas

- Sistema de espaçamento em incrementos de 4/8 px.
- Padding do conteúdo: 24–28 px no desktop, 16 px no mobile.
- Gap entre os cards principais: 18–24 px.
- Padding interno dos cards: 20–24 px.
- Radius de cards: 14–16 px.
- Radius de chips: 999 px.
- Bordas: 1 px, com sombra suave opcional.
- Alvos clicáveis: altura ideal de 40–44 px.
- Altura mínima para linhas de tabela: 48–54 px.
- Fundo dos cards predominantemente sólido; iluminação sutil somente onde melhorar hierarquia.

---

## 4. Layout de referência (desktop)

O PNG principal tem **1672 × 941 px** e ilustra uma tela ampla. A aplicação não deve ter dimensões fixas, mas o layout-base deve manter estas proporções:

```text
┌────────────────────┬──────────────────────────────────────────────────────────┐
│                    │  CASE OVERVIEW                [PESQUISA]       [PERFIL] │
│   DetectiveDB      │  Caso 001 — O Relógio Parado                             │
│                    ├────────────┬────────────┬────────────┬──────────────────┤
│   Dashboard        │ Suspeitos  │ Evidências │ Contradiç. │ Testes dbt       │
│   Suspeitos        │     8      │     25     │     3      │  24/25          │
│   Evidências       ├────────────┴────────────┼────────────┴──────────────────┤
│   Qualidade        │ TOP SUSPEITOS           │ FEED DE EVIDÊNCIAS            │
│   Configurações    │ [Tabela compacta]       │ [Miniaturas e status]         │
│                    │                         │                               │
│                    ├─────────────────────────┼───────────────────────────────┤
│                    │ CONTRADIÇÕES            │ QUALIDADE DOS DADOS           │
│                    │ [Contagem + revisar]    │ [Anel + aprovados/falhos]      │
│                    │                         │                               │
│ [CENA DECORATIVA]  │                         │                               │
└────────────────────┴─────────────────────────┴───────────────────────────────┘
```

**Atenção:** os valores do diagrama são apenas demonstrações de posicionamento; jamais copiá-los para a UI.

### 4.1 Proporções recomendadas

- **Sidebar:** 236–250 px de largura no desktop, com fundo independente.
- **Área principal:** largura flexível restante, com padding horizontal de 26–30 px.
- **Cabeçalho:** altura visual ~95–115 px, sem card pesado ao redor.
- **KPIs:** 4 colunas de largura igual, cards com altura de 100–116 px.
- **Linha principal:** duas colunas, com tabela de suspeitos ocupando **55–57%** e evidências **43–45%**.
- **Linha inferior:** duas colunas com contradições e qualidade de dados, aproximadamente 52% / 48%.
- **Margens:** respeitar espaços de 18–24 px entre blocos; não encostar no rodapé da viewport.

### 4.2 Grid responsivo

| Largura do viewport | Comportamento |
|---|---|
| `>= 1360 px` | Sidebar fixa + 4 KPIs em linha + 2 colunas nas seções |
| `1024–1359 px` | Sidebar compacta, 4 KPIs menores ou 2×2 conforme espaço; duas colunas se legíveis |
| `768–1023 px` | Navegação colapsável, KPIs em 2×2, seções empilhadas ou com proporção ajustada |
| `< 768 px` | Uma coluna, busca reduzida, cards empilhados, sem fundo decorativo complexo |

Use componentes `st.columns` e CSS de contêiner, com media queries moderadas. Não forçar larguras que provoquem rolagem horizontal. Uma sidebar nativa do Streamlit pode colapsar automaticamente; se a versão do Streamlit limitar a disposição, priorizar uma interface funcional e responsiva em vez de hacks frágeis.

---

## 5. Sidebar — menu e marca

### Elementos, de cima para baixo

1. **Marca:** `detective_mark.png` (símbolo) centralizado ou à esquerda; ao lado/abaixo, texto **DetectiveDB** (branco + `DB` vermelho). Subtítulo curto `INVESTIGATIVE DATA PLATFORM` ou `PLATAFORMA DE INVESTIGAÇÃO`.
2. **Menu principal:** `Dashboard`, `Suspeitos`, `Evidências`, `Qualidade dos Dados`, `Configurações`.
3. **Estado ativo:** item com fundo bordô discreto, texto branco e ícone correspondente.
4. **Rodapé decorativo:** imagem `sidebar_scene.png`, ancorada ao fundo, com fade escuro de cima para baixo para não comprometer a leitura.

### Comportamento

- Todo item deve mudar efetivamente de página ou seção.
- Destacar exatamente um item ativo.
- Lembrar a página atual durante reruns do Streamlit.
- Quando a sidebar estiver colapsada no mobile, a navegação deve continuar acessível.
- A imagem decorativa não deve capturar cliques nem ficar atrás de texto navegável a ponto de prejudicar contraste.
- Renderizar o nome do app como texto real, não como parte de uma imagem borrada.

**Implementação sugerida:** `st.sidebar` com `st.button` ou navegação multipágina; se usar botões, atualizar `st.session_state.page` e executar `st.rerun()` somente quando a seleção mudar. Ícones pequenos e uniformes.

---

## 6. Cabeçalho — Case Overview

### Layout

- Título **`Case Overview`** ou **`Visão geral do caso`**, com barra vertical vermelha fina à esquerda.
- Linha de contexto logo abaixo, por exemplo `Caso 001 | O Relógio Parado | Em investigação`.
- Barra de pesquisa à direita ou abaixo em viewport menor.
- Indicador de status discreto, não uma grande caixa chamativa.
- `header_city.png` pode aparecer como imagem de atmosfera na faixa superior, usando opacidade baixa e sobreposição de gradiente. Não deve reduzir legibilidade.

### Pesquisa

A busca precisa funcionar, pelo menos, para:

- nome/identificador do suspeito;
- descrição/identificador da evidência;
- nome de local, se a coluna estiver disponível.

**MVP aceitável:** campo que atualiza `st.session_state.search_query` e filtra a tabela e/ou redireciona para a página correspondente. Não desenhar uma barra sem comportamento. Se a pesquisa global não estiver implementada na primeira fase, usar um campo desabilitado com indicação explícita ou não exibi-lo inicialmente.

### Origem das informações

O nome do caso pode vir de uma pequena configuração local (`app/config.py`) enquanto houver apenas um caso fictício. IDs de caso e status não precisam ser inventados a partir das tabelas se o projeto ainda não possui uma tabela de casos.

---

## 7. Primeira linha — quatro KPIs

**Exatamente quatro indicadores** na home inicial:

| KPI | Rótulo de referência | Fonte de verdade | Regras de exibição |
|---|---|---|---|
| 1 | Total de suspeitos | `dim_suspects` ou `mart_case_summary` | Contar `DISTINCT suspect_id` |
| 2 | Evidências | `fct_evidence` | Contar evidências válidas conforme regra documentada |
| 3 | Contradições abertas | Modelo de conflitos, ou soma de conflitos em `mart_case_summary` | Contar conflitos, não total de suspeitos, e não dobrar contagem |
| 4 | Testes dbt aprovados | `detective_dbt/target/run_results.json` | Mostrar `aprovados/avaliados` e percentual real |

### Visual

- Card de fundo `--bg-panel`, borda suave.
- Ícone pequeno à esquerda dentro de quadrado arredondado, na cor semântica.
- Título menor acima do número.
- Número grande abaixo do título.
- Cores: suspeitos = vermelho discreto; evidências = âmbar; contradições = vermelho; qualidade = azul/verde.
- **Não exibir sparklines nem deltas `+x nas últimas 24h`** sem histórico temporal real.

### Estados vazios e falhas

- Banco não encontrado: exibir `—` em vez de inventar `8`, `42` etc.; explicar que a ingestão ainda não foi executada.
- Tabela inexistente: mostrar mensagem clara de setup, sem tracebacks na página.
- Testes não executados: `Ainda não executados`, sem interpretar ausência de arquivo como 100% aprovado.
- Resultado antigo: exibir o horário da última execução e, se possível, aviso `Resultados podem estar desatualizados`.

---

## 8. Painel Top Suspects / Principais suspeitos

### Estrutura

Card mais largo da primeira linha, contendo:

- título `Top Suspects` ou `Principais suspeitos`;
- opcional `Ver todos` como botão real;
- tabela compacta com 4–6 linhas por padrão;
- colunas: **Suspeito**, **Situação do álibi** e **Índice de investigação** (ou `Pontuação`).

O número/rank à esquerda pode aparecer discretamente. Não incluir coluna de profissão ou evidências na home se isso prejudicar espaço — esses detalhes ficam na página de suspeitos.

### Fonte de dados

Priorizar `mart_case_summary`. Campos esperados pelo contrato original:

```text
suspect_id
suspect_name
evidence_count
testimony_count
camera_events_count
inconsistent_testimony_count
alibi_camera_conflict_count
contradiction_flag
suspicion_score
```

Ordenar por `suspicion_score DESC`, com desempate estável por `suspect_name` ou `suspect_id`. Exibir `LIMIT 5` (configurável).

### Score: requisito fundamental

O projeto original calcula um **score heurístico**, por exemplo somando pesos por evidência e conflito. Esse valor **não é uma probabilidade de culpa**.

- Não simplesmente colar `%` depois do score se o SQL não fornecer uma métrica de 0 a 100.
- Para reproduzir a barra visual, definir uma escala de exibição documentada (por exemplo, `min(score / 100, 1)`) e nomeá-la `índice normalizado`, **ou** exibir a pontuação bruta com barra relativa ao máximo da amostra, deixando claro que a barra é comparativa.
- Preferência: `Pontuação: 24 pontos`, barra comparativa ao maior valor, com tooltip/legenda `Indicador fictício de priorização investigativa; não é evidência de culpa`.
- O frontend não deve recalcular pesos diferentes dos implementados no SQL, exceto para normalização puramente visual.

### Situação do álibi

Estados sugeridos:

- `Conflito identificado` (vermelho) quando `alibi_camera_conflict_count > 0`;
- `Informação inconsistente` (âmbar) se há depoimentos marcados como inconsistentes mas nenhum conflito estruturado;
- `Sem conflito detectado` (cinza/azul) quando não há alertas suficientes;
- `Sem informação` (cinza) quando faltam dados.

**Não usar `Inocente`, `Culpado` ou `Álibi verificado` sem dado que sustente isso.** Não deduzir que ausência de conflito é álibi confirmado.

### Interação

- Clicar em `Ver todos` abre `Suspeitos`.
- Clicar em um suspeito, se houver botão/link implementável com Streamlit, abre detalhe ou ativa filtro daquele suspeito.
- Hover de linha discreto, foco visível para navegação via teclado.
- Não criar linhas falsas só para preencher espaço.

---

## 9. Painel Evidence Feed / Feed de evidências

### Estrutura

Card à direita da tabela, com título, no máximo **três itens visíveis** na página inicial e botão `Ver todas`.

Cada linha deve ter:

```text
[imagem 105×64]  Título/tipo da evidência           [chip de status]
                  Descrição curta, local ou referência
```

- Miniaturas com largura e altura consistentes, borda arredondada de 8–10 px.
- Cortar via `object-fit: cover`, sem distorcer.
- Texto de título em branco e descrição em cinza.
- Separadores discretos e espaçamento de 14–16 px.
- Sem datas extensas ou metadados demais na home.

### Origem dos dados

Usar `fct_evidence` (possivelmente com `JOIN dim_locations` e `JOIN dim_suspects`) para apresentar:

- `evidence_id`;
- `evidence_type`;
- `evidence_description`;
- `collected_at`;
- `status`;
- `suspect_id` e/ou `location_id`, quando disponíveis.

Ordenar por `collected_at DESC NULLS LAST, evidence_id` e limitar a 3. Se a tabela final não tiver todas as colunas, adaptar a consulta com base no esquema existente, sem inventar atributos.

### Mapeamento de imagens

Criar uma função única de mapeamento de tipos:

```python
# Esquema ilustrativo; adaptar aos valores reais do CSV.
THUMBNAIL_BY_TYPE = {
    "CAMERA": "assets/evidence/camera_footage.png",
    "CAMERA_FOOTAGE": "assets/evidence/camera_footage.png",
    "DIGITAL": "assets/evidence/digital_evidence.png",
    "DIGITAL_EVIDENCE": "assets/evidence/digital_evidence.png",
    "PHYSICAL": "assets/evidence/physical_evidence.png",
    "PHYSICAL_EVIDENCE": "assets/evidence/physical_evidence.png",
}
```

Se os valores reais forem outros (`PHOTO`, `DOCUMENT`, etc.), mapear conscientemente para uma imagem ilustrativa apropriada ou placeholder neutro. **Não representar um arquivo sem vídeo como vídeo real.**

### Status

- `COLLECTED` → `Coletada` / badge cinza-azul;
- `ANALYZED` → `Analisada` / badge âmbar ou verde, conforme semântica adotada;
- `DISCARDED` → `Descartada` / badge cinza;
- valor desconhecido → `Status desconhecido` / badge neutro.

Na lista de detalhe, permitir filtro por tipo, status e suspeito, bem como acesso à descrição completa.

---

## 10. Painel Contradições

### Layout da home

Card inferior esquerdo:

- ícone de atenção pequeno e título `Contradições`;
- um número grande calculado da base;
- texto curto: `Possíveis conflitos entre álibis e registros de câmera.`;
- botão real `Revisar`.

Este painel deve ser intencionalmente simples. **Não renderizar cronologia detalhada, mapa de relações ou lista de 10 alertas na home.**

### Regras de negócio

No MVP, uma contradição estruturada é um possível conflito entre:

- `claimed_location_id` e `claimed_event_time` de um depoimento;
- `location_id` e `seen_at` de um evento de câmera do mesmo suspeito;
- horário próximo dentro da janela especificada pela transformação SQL;
- locais diferentes.

Essas regras devem existir no pipeline SQL/dbt; a UI apenas as consome. O frontend **não deve criar uma segunda lógica conflitante** de detecção.

Se a agregação `alibi_camera_conflict_count` já existe em `mart_case_summary`, usar essa coluna para a contagem na home. Para exibir **cada conflito individual** na página de contradições, preferir um modelo adicional `mart_alibi_conflicts` com chaves de depoimento/evento. Se esse modelo não existir, apresentar resumo por suspeito e explicar o nível de granularidade disponível.

**Importante:** inconsistência de dados, conflito de álibi e evidência incriminadora são conceitos diferentes. Usar linguagem condicional (`possível conflito`, `requer análise`) e nunca produzir acusações automáticas.

### Página de detalhe

Mostrar tabela filtrável contendo, se disponível:

- suspeito;
- local alegado;
- horário alegado;
- local observado;
- horário observado;
- diferença em minutos;
- evidências relacionadas;
- nível de atenção baseado em critérios explícitos.

Botão para voltar ao Dashboard e opção de filtrar por suspeito.

---

## 11. Painel Data Quality (dbt Tests)

Esta é uma das seções **mais importantes** do projeto porque demonstra diretamente o desafio original.

### Layout da home

Card inferior direito com:

- título `Qualidade dos Dados` + detalhe `dbt Tests`;
- anel/donut simples (predominantemente verde se os testes passaram; vermelho discreto para falhas);
- percentual no centro do anel, somente se houver resultados;
- três números ao lado: `Aprovados`, `Falhos`, `Avaliados`;
- botão/link `Relatório completo` se houver navegação.

Não mostrar métricas inventadas como `96%` / `24 de 25` da arte: essas são meramente ilustrativas.

### Fonte oficial — artefato do dbt

Ler o arquivo gerado pelo comando `dbt test` ou `dbt build`:

```text
detective_dbt/target/run_results.json
```

Ele contém um array `results`. Para métricas **de testes**, filtrar entradas com `unique_id` começando por `test.` (ou identificar o tipo de recurso por manifesto, se necessário). Interpretar `status` de acordo com os resultados reais do dbt: normalmente `pass`, `fail`, `warn`, `error`, `skipped`.

Contrato da apresentação:

```text
passed = número de testes com status 'pass'
failed = número de testes com status 'fail' ou 'error'
warned = número de testes com status 'warn'
skipped = número de testes ignorados
assessed = passed + failed + warned
pass_rate = passed / assessed * 100, somente se assessed > 0
```

É permitido destacar `warned` em âmbar no relatório detalhado. Não considerar um teste `skipped` como aprovado. Se `run_results.json` foi gerado apenas por `dbt run`, pode não haver resultados de teste; nesse caso mostrar **`Sem testes nesta execução`**.

### Atualização e cache

- Informar o horário do arquivo/execução do teste quando disponível.
- Atualizar os indicadores após novo teste, com botão `Atualizar` ou cache de curto prazo.
- Se CSV/DB for alterado após o teste, indicar que os resultados podem estar antigos quando for possível comparar timestamps.
- Evitar manter JSON obsoleto em cache indefinidamente.
- Se não houver arquivo, a interface continua funcionando; nunca preencher com números mock sem aviso.

### Implementação do gráfico

Usar uma destas opções, nesta ordem:

1. **SVG simples/CSS** construído a partir dos contadores reais, se isso não comprometer acessibilidade;
2. **Plotly** com gráfico `Pie` + `hole=0.76`, desativando toolbar/legenda e configurando fundo transparente;
3. Caso Plotly não esteja instalado e não faça sentido adicioná-lo, usar **barra de progresso** estilizada com números textuais.

Nunca fazer um gráfico de anel bonito com números que não correspondam aos testes.

### Tela de qualidade completa

Criar tabela por teste/resultado, com:

- nome (`unique`, `not_null`, `relationships`, custom etc.);
- recurso/modelo;
- status;
- quantidade de falhas quando disponível;
- horário de execução;
- mensagem curta/erro, quando existente.

Mostrar exemplo do experimento de dados sujos somente se logs e artefatos estiverem disponíveis. Não executar scripts de injeção automaticamente ao abrir o dashboard.

### Comportamento durante o desafio original

1. Pipeline normal executa `dbt run`/`dbt test`.
2. `scripts/inject_bad_data.py` insere evidência com ID duplicado na camada bruta.
3. Um teste `unique` na **source raw** (ou modelo que não esconda a duplicação) deve falhar.
4. O `dbt test` retorna status de falha no processo; a UI passa a refletir a falha após refresh.
5. `scripts/reset_demo.py` restaura os dados; rodar testes de novo; UI atualiza para o resultado aprovado.

**Nuance técnica:** `dbt test` verifica dados e retorna código de saída, mas sozinho **não interrompe magicamente todos os outros jobs**. Para barrar execução downstream, orquestrar por código de saída e/ou usar `dbt build` com dependências e testes configurados. Não fazer promessa incorreta na interface.

---

## 12. Páginas e navegação do MVP

A home precisa ser limpa. Dados mais extensos ficam nas páginas secundárias:

### `Dashboard`

- Cabeçalho do caso.
- Quatro KPIs.
- Top 5 suspeitos.
- Feed com as três evidências mais recentes.
- Resumo de contradições.
- Qualidade dos testes dbt.

**Sem gráficos adicionais, cronologia complexa ou mapa de relacionamentos na home.**

### `Suspeitos`

- Pesquisa por nome/ID.
- Tabela completa com profissão, evidências, depoimentos, eventos de câmera, pontuação e indicador de contradição.
- Seleção de suspeito para detalhes de informações existentes.
- Filtros por conflito e faixas de pontuação.
- Link/ação `Voltar ao Dashboard`.

### `Evidências`

- Listagem completa com tipos, status, local, data/hora e descrição.
- Filtros por tipo, status, local e suspeito quando existir chave.
- Miniaturas ilustrativas por categoria; conteúdo da evidência vem do banco.
- Evitar abrir modais sem conteúdo real.

### `Contradições`

- Pode ser página secundária acessada pelo botão `Revisar`, mesmo que não apareça no menu principal da sidebar.
- Listar conflitos estruturados e indicar o motivo.
- Mostrar `Sem conflitos detectados` quando a regra SQL resultar em zero.

### `Qualidade dos Dados`

- Sumário de testes (aprovados/falhos/avisos).
- Listagem de testes dbt com resultados reais.
- Metadados da última execução.
- Instrução de como reproduzir injeção de erro **por script**, com comando explícito no README.
- Aviso se não existem artefatos.

### `Configurações`

- Exibir caminho do banco e status da conexão (sem dados sensíveis).
- Exibir caminho de artefatos de testes.
- Exibir versão do aplicativo/pipeline se disponível.
- Botão `Atualizar dados` para limpar caches relevantes.
- Configuração de janela de conflito somente se for sincronizada com o SQL e claramente documentada; não manter controles que não alteram nada.

---

## 13. Organização recomendada do código Streamlit

Preservar a estrutura do projeto original e incrementar `app/` com componentes simples:

```text
app/
├── streamlit_app.py
├── config.py
├── components/
│   ├── sidebar.py
│   ├── header.py
│   ├── kpi_card.py
│   ├── suspects_table.py
│   ├── evidence_feed.py
│   ├── contradictions_card.py
│   ├── quality_card.py
│   └── states.py
├── pages/
│   ├── dashboard.py
│   ├── suspects.py
│   ├── evidence.py
│   ├── contradictions.py
│   ├── quality.py
│   └── settings.py
├── services/
│   ├── db.py
│   ├── repositories.py
│   └── dbt_artifacts.py
└── styles/
    ├── detectivedb_tokens.css
    └── streamlit_overrides.css
```

> Esta organização é **sugestão**, não obrigação de criar 20 arquivos vazios. Para um MVP, consolidar componentes pequenos quando apropriado. A meta é clareza, não quantidade de arquivos.

### Responsabilidades

- `streamlit_app.py`: configurar `st.set_page_config`, carregar estilos, coordenar a navegação e exibir a página escolhida.
- `config.py`: resolver caminhos usando `Path(__file__).resolve()`; metadados do caso e limites de exibição.
- `components/*`: apenas apresentação e callbacks UI, sem `JOIN` complexo embutido.
- `services/db.py`: conexão read-only ao DuckDB, tratamento de erros, queries parametrizadas.
- `services/repositories.py`: buscar dados prontos do `mart_case_summary`, `fct_evidence` etc.
- `services/dbt_artifacts.py`: leitura robusta de `run_results.json` e métricas derivadas.
- `pages/*`: montar componentes e aplicar filtros, chamando os serviços.
- `styles/*`: tokens e ajustes leves de CSS.

### Dependências mínimas

Respeitar `requirements.txt` existente. Se faltarem, adicionar:

```text
streamlit
duckdb
pandas
```

`plotly` só se escolhido como implementação do donut. O pipeline original também depende de `dbt-core` e `dbt-duckdb`, mas não é necessário instalar dbt dentro da UI se ela apenas lê o banco e o JSON dos testes. Usar versões compatíveis e, na etapa de finalização, registrar/pinar as versões testadas.

---

## 14. Contrato de integração com DuckDB

### Caminho e segurança

Banco padrão:

```text
<repo>/data/detectivedb.duckdb
```

Conectar em modo leitura no frontend, para que navegar na UI não altere os dados:

```python
from pathlib import Path
import duckdb

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DB_PATH = PROJECT_ROOT / "data" / "detectivedb.duckdb"

if DB_PATH.exists():
    con = duckdb.connect(str(DB_PATH), read_only=True)
    try:
        # Execute consultas SELECT.
        ...
    finally:
        con.close()
```

**Nota:** a profundidade de `parents[2]` depende de qual arquivo contém a função. Resolver o caminho em `app/config.py` e importar `PROJECT_ROOT` nos módulos para evitar caminhos divergentes.

**Não:** executar SQL de origem controlada pelo usuário, concatenar diretamente a string digitada no campo de pesquisa, criar/alterar tabelas ao abrir a UI ou manter uma conexão que impede operações dbt por bloqueio de arquivo.

### Consultas esperadas

Verificar os schemas reais e ajustar SQL. Exemplos conceituais:

```sql
-- KPI de suspeitos
SELECT COUNT(DISTINCT suspect_id) AS total
FROM marts.dim_suspects;

-- KPI de evidências
SELECT COUNT(DISTINCT evidence_id) AS total
FROM marts.fct_evidence;

-- Ranking consolidado
SELECT
    suspect_id,
    suspect_name,
    suspicion_score,
    alibi_camera_conflict_count,
    inconsistent_testimony_count,
    evidence_count
FROM marts.mart_case_summary
ORDER BY suspicion_score DESC NULLS LAST, suspect_name
LIMIT 5;
```

**Esses nomes com prefixo `marts.` são ilustrativos:** descobrir o schema de destino configurado no `dbt_project.yml` e no perfil real. O dbt-duckdb pode materializar modelos em outro schema; não fixar `marts` sem confirmar.

### Tratamento de estados

O repositório precisa suportar:

- `NotInitialized`: arquivo DuckDB não foi criado.
- `MissingModel`: banco existe, mas a tabela/modelo ainda não foi materializado.
- `EmptyDataset`: consulta válida com zero resultados.
- `AccessError`: erro de permissão/arquivo bloqueado.
- `Ok`: dados válidos.

Na UI, mostrar mensagens práticas, por exemplo: `Nenhum dado encontrado. Execute a ingestão e depois dbt run.` Evitar tracebacks e `except: pass` silencioso.

### Atualização dos dados

- Usar `@st.cache_data(ttl=30)` ou cache com chave baseada no horário de modificação do banco/artefato.
- Incluir botão de refresh, com `st.cache_data.clear()` caso necessário.
- Não tratar cache como mecanismo de orquestração: novos dados só estarão disponíveis após ingestão e execução de dbt.
- Se a aplicação rodar durante escrita no DuckDB, instruir o usuário a atualizar após o término do pipeline.

---

## 15. Boas práticas de implementação no Streamlit

### 15.1 Estrutura básica

Usar:

```python
import streamlit as st

st.set_page_config(
    page_title="DetectiveDB | Visão geral",
    page_icon="🔎",
    layout="wide",
    initial_sidebar_state="expanded",
)
```

Configurar a página **antes** de renderizar componentes. Evitar inserir HTML de corpo completo ou scripts JavaScript para simular um frontend SPA.

### 15.2 HTML/CSS vs componentes nativos

- Usar **Streamlit nativo** para navegação, busca, filtros, botões, seleção de suspeitos, tabelas clicáveis e estados reativos.
- Usar `st.html()`/CSS ou `st.markdown(..., unsafe_allow_html=True)` apenas quando necessário para elementos **de apresentação estática**, como moldura de cards, pequenos badges e detalhes visuais.
- Se construir HTML a partir de dados dos CSVs, **escapar o conteúdo** com `html.escape` e tratar `None`/NaN. Nunca interpolar texto de depoimentos sem sanitização.
- Evitar selecionar classes CSS internas geradas aleatoriamente. Preferir atributos estáveis conhecidos da versão utilizada ou wrappers próprios; encapsular overrides.
- Não estilizar texto como botão se ele não tiver ação real.

### 15.3 Comportamento do menu

Exemplo simplificado:

```python
if "page" not in st.session_state:
    st.session_state.page = "dashboard"

# Os botões reais devem atualizar page e rerenderizar a seção.
```

Qualquer abordagem diferente (como `st.navigation` e `st.Page`) é válida se for estável na versão escolhida e mantiver a sidebar coerente.

### 15.4 Gráficos

Um único donut de qualidade já é suficiente no dashboard. Não adicionar gráficos extras para cada KPI. Para histórico e comparações, reservar páginas secundárias.

### 15.5 Acessibilidade

- Contraste adequado para texto e badges; não depender apenas de cores.
- Todos os ícones informativos possuem texto alternativo ou rótulo acessível.
- Todos os botões são alcançáveis pelo teclado.
- Foco visível.
- Descrições em português, consistentes com a terminologia usada no código.
- Mensagens de erro compreensíveis.

---

## 16. CSS de partida e componentes

O pacote contém `app/styles/detectivedb_tokens.css` com tokens básicos. É aceitável adaptá-lo, mas **não substituir a lógica de layout inteira por CSS frágil**.

### Card base

```css
.ddb-card {
    background: var(--bg-panel);
    border: 1px solid var(--border);
    border-radius: var(--radius-card);
    padding: 22px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, .12);
}

.ddb-card__title {
    font-size: 18px;
    font-weight: 650;
    color: var(--text-primary);
    margin: 0 0 14px;
}
```

### Badge

```css
.ddb-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    min-height: 25px;
    padding: 4px 10px;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 600;
    white-space: nowrap;
}

.ddb-badge--danger { color: #FF8588; background: rgba(240, 82, 85, .14); }
.ddb-badge--warning { color: #F2C16F; background: rgba(233,170,73,.13); }
.ddb-badge--success { color: #70E1A0; background: rgba(61,204,120,.13); }
.ddb-badge--neutral { color: #BCC9D6; background: rgba(130,150,165,.12); }
```

### Barra comparativa de score

- Fundo `#25303B`, altura aproximada de 8 px, arredondada.
- Segmento preenchido com cor semântica (vermelho/âmbar/azul).
- Largura calculada com base em valor normalizado apenas para **visualização**.
- Exibir a pontuação numérica como texto acessível.
- O significado da cor deve ser definido no projeto; não utilizar rótulo `92% de chance de culpa`.

### Imagens

```css
.ddb-evidence-thumb {
    width: 105px;
    height: 64px;
    object-fit: cover;
    border-radius: 10px;
    flex: 0 0 auto;
    background: #202A34;
}
```

### Efeitos

- Hover: realce de superfície discreto, duração 120–180 ms.
- Transições somente para hover/focus e preenchimento de barra.
- Nada de pulsos constantes em alertas nem glow contínuo no topo.
- Bordas de cards devem ser quase neutras; colorir **ícones, status e detalhes**, não todas as bordas.

---

## 17. Etapas de implementação para a IA

Implementar **em fases com validação em cada uma**. Não gerar a UI inteira no escuro sem testar carregamento e consultas.

### Fase 1 — Inspeção do projeto existente

1. Ler `docs/DetectiveDB_ESPECIFICACAO.md` e arquivos já existentes.
2. Identificar stack exata, comando de start, caminhos, schemas DuckDB e nomes reais de modelos.
3. Verificar se existe banco DuckDB, modelos dbt e `run_results.json`.
4. Não sobrescrever dados ou alterações do usuário sem necessidade.
5. Registrar rapidamente o que existe e o que precisa ser criado.

**Entregável:** projeto inspecionado, estrutura final planejada e assets copiados para os caminhos corretos.

### Fase 2 — Estilos, sidebar e cabeçalho

1. Aplicar tema dark.
2. Criar sidebar com marca e navegação.
3. Adicionar `sidebar_scene.png` sem obstruir menu.
4. Criar cabeçalho simples com nome do caso, status e pesquisa funcional ou explicitamente indisponível.
5. Verificar visualmente o layout em desktop.

**Entregável:** estrutura visual funcional antes de adicionar cards de dados.

### Fase 3 — Serviços de dados

1. Criar módulo único de caminhos/configuração.
2. Implementar conexão DuckDB somente leitura.
3. Implementar consultas para KPIs, suspeitos e evidências, com filtros.
4. Criar parser robusto de `run_results.json`.
5. Adicionar estados `sem banco`, `modelo ausente`, `sem testes`.
6. Testar as consultas com banco de demonstração existente, se disponível.

**Entregável:** valores corretos sem mocks silenciosos.

### Fase 4 — Dashboard enxuto

1. Exibir 4 KPI cards.
2. Exibir top suspeitos com pontuação e badges.
3. Exibir 3 evidências com miniaturas.
4. Exibir contradições com botão revisar.
5. Exibir donut real de testes dbt.
6. Ajustar alinhamento, alturas e comportamento responsivo.

**Entregável:** dashboard parecido com `ui_reference_clean.png` e alimentado pelo pipeline.

### Fase 5 — Páginas secundárias

1. Suspeitos: lista completa + filtros + detalhes.
2. Evidências: catálogo + filtros.
3. Contradições: listagem de conflitos reais.
4. Qualidade: resultados detalhados de testes.
5. Configurações: caminhos e atualização de dados.
6. Validar todos os botões de navegação.

**Entregável:** experiência navegável sem links/botões falsos.

### Fase 6 — Demonstração de qualidade e revisão final

1. Rodar ingestão e dbt conforme o README do projeto.
2. Mostrar estado saudável.
3. Inserir registro duplicado usando script de demonstração.
4. Executar `dbt test`/`dbt build` conforme fluxo definido; verificar falha real.
5. Atualizar página de qualidade; mostrar o teste falho.
6. Restaurar dados e executar novamente.
7. Confirmar que a taxa de aprovação reflete o último resultado.
8. Verificar abertura do app sem banco (mensagens amigáveis), layouts e lint/testes disponíveis.

**Entregável:** screenshots reais da UI, logs do experimento e README atualizado.

---

## 18. Critérios objetivos de aceitação

### Visual

- [ ] A imagem `reference/ui_reference_clean.png` foi usada como guia, não exibida no lugar da aplicação.
- [ ] A home possui sidebar, cabeçalho, 4 KPIs, Top Suspects, Evidence Feed, Contradições e Data Quality.
- [ ] Há espaço entre os blocos e não existem mais de quatro cards na linha de KPIs.
- [ ] A barra lateral contém marca, cinco itens de navegação e arte decorativa bem integrada.
- [ ] A home não contém mapa de relacionamentos, cronologia complexa ou painéis extras que poluam o layout.
- [ ] A interface é legível em 1440×900 e 1366×768; também funciona em mobile.
- [ ] PNGs usados nos lugares previstos, com recorte proporcional e sem esticar.

### Funcional

- [ ] `streamlit run app/streamlit_app.py` inicia sem exceção.
- [ ] Os indicadores são calculados a partir do banco/JSON real.
- [ ] Top Suspects lê o mart real e ordena pelo score real.
- [ ] Feed de evidências lê as evidências reais, não uma lista hardcoded.
- [ ] Contradições refletem a regra SQL, sem duplicar contagens.
- [ ] Página de qualidade lê resultados verdadeiros de testes dbt.
- [ ] Ausência de banco/modelos/artefatos gera mensagens explícitas, não dados inventados.
- [ ] Sidebar e botões de acesso às páginas têm comportamento funcional.
- [ ] A busca ou filtro implementado responde ao usuário.

### Engenharia

- [ ] Os testes de dbt são executados fora da UI ou por workflow explícito e seguro.
- [ ] O dbt continua sendo a fonte da transformação/validação; a UI não reproduz toda a regra de negócio em Python.
- [ ] Query de busca é parametrizada.
- [ ] Campos originados de CSV são escapados quando renderizados em HTML.
- [ ] Arquivo DuckDB não é escrito pela UI.
- [ ] Caminhos são independentes do diretório de execução.
- [ ] Nenhum segredo é incluído no repositório.
- [ ] O README documenta instalação, comandos, integração e limitações.

---

## 19. Exemplo de comando de execução e validação

Os comandos abaixo são ilustrativos e devem ser ajustados aos scripts, schemas e arquivos realmente encontrados:

```bash
# 1. Instalar dependências
pip install -r requirements.txt

# 2. Ingerir CSVs fictícios no DuckDB
python scripts/ingest_raw.py

# 3. Construir modelos dbt
cd detective_dbt
dbt run --profiles-dir .

# 4. Validar os modelos
dbt test --profiles-dir .

# 5. Voltar para a raiz do repositório
cd ..

# 6. Abrir a interface
streamlit run app/streamlit_app.py
```

Se `dbt test` detectar erros, os artefatos da última execução continuam relevantes para o painel de qualidade. A implementação deve explicar como atualizar e interpretar o resultado.

**No Colab:** executar principalmente o pipeline e mostrar os logs do dbt e resultados do DuckDB; a UI Streamlit pode ficar como componente para execução local. Não tornar um túnel público uma dependência para completar o desafio.

---

## 20. Textos da interface (pt-BR recomendado)

| Elemento | Texto |
|---|---|
| Nome | `DetectiveDB` |
| Dashboard | `Visão geral do caso` |
| Caso | `Caso 001 — O Relógio Parado` |
| Status | `Em investigação` |
| KPI 1 | `Suspeitos` |
| KPI 2 | `Evidências` |
| KPI 3 | `Contradições` |
| KPI 4 | `Testes dbt aprovados` |
| Tabela | `Principais suspeitos` |
| Coluna 1 | `Suspeito` |
| Coluna 2 | `Situação do álibi` |
| Coluna 3 | `Pontuação` |
| Feed | `Evidências recentes` |
| Qualidade | `Qualidade dos dados` |
| CTA | `Revisar contradições` |
| Estado vazio | `Nenhum registro disponível` |
| Sem DB | `O banco ainda não foi inicializado. Execute a ingestão e os modelos dbt.` |
| Sem teste | `Ainda não há resultados de testes dbt nesta execução.` |
| Sem conflito | `Nenhum conflito detectado pelas regras atuais.` |
| Aviso do score | `Índice heurístico fictício para priorização investigativa; não representa culpa.` |

Se o projeto usa inglês em todo o código/UI, pode manter labels em inglês como na referência; **não misturar idiomas aleatoriamente**. Escolher pt-BR por padrão nos textos visíveis, mantendo nomes técnicos como `dbt`, `DuckDB`, `unique` e `not_null`.

---

## 21. Falhas frequentes a evitar

1. **Copiar os números da imagem** (8 suspeitos, 42 evidências, 96%) em vez de calcular: proibido, a menos que coincidam com consultas reais.
2. **Mostrar `96% de testes passando` quando `run_results.json` não existe:** exibir `Não executado`.
3. **Esconder uma duplicação no staging** com `DISTINCT` e depois afirmar que o teste demonstrou a falha: validar a fonte `raw` ou uma tabela que preserve o erro.
4. **Confundir score com probabilidade de culpa:** nunca apresentar como conclusão judicial ou matemática probabilística.
5. **Colocar fotos como cards de navegação**: os PNGs são recursos decorativos e miniaturas, não substituem componentes.
6. **Criar botões sem ação** apenas para imitar screenshot.
7. **Criar um arquivo HTML isolado estático** quando o pedido é uma UI Streamlit funcional.
8. **Inventar modelos dbt** que não existam: pode propor um modelo novo, mas implementá-lo no pipeline e atualizar documentação antes de depender dele.
9. **Fazer conexão DuckDB read-write na interface** ou deixar arquivo aberto indefinidamente.
10. **Usar CSS específico demais** atrelado a hashes/classes internas que quebram em cada versão do Streamlit.
11. **Exagerar no cenário investigativo:** fundo artístico só na sidebar e talvez no header, jamais sobre tabelas.
12. **Duplicar testes e cálculo de score em Python** quando já existem no dbt.

---

## 22. Prompt final pronto para a IDE

Copie o bloco abaixo para o agente de código, junto do ZIP extraído (ou apontando para o arquivo atual):

```text
Leia integralmente DETECTIVEDB_UI_IMPLEMENTACAO.md e
 docs/DetectiveDB_ESPECIFICACAO.md. Inspecione a base atual do repositório
 e implemente a UI do DetectiveDB em Streamlit, tomando
 reference/ui_reference_clean.png como REFERÊNCIA VISUAL e usando os PNGs
 existentes em assets/.

Requisitos não negociáveis:
- reproduzir o layout dark/noir MINIMALISTA da referência: sidebar,
  cabeçalho, quatro KPIs, principais suspeitos, feed de evidências,
  resumo de contradições e qualidade dos testes dbt;
- usar dados de verdade do DuckDB e resultados reais de
  detective_dbt/target/run_results.json; nunca hardcodar números da imagem;
- preservar a arquitetura Python + DuckDB + dbt Core, sem introduzir
  frontend React ou serviços externos sem motivo;
- tornar a navegação, filtros e ações principais funcionais;
- lidar elegantemente com banco inexistente, tabelas ausentes,
  datasets vazios e testes ainda não executados;
- não exibir suspicion_score como probabilidade de culpa;
- respeitar os arquivos, nomes e contratos já existentes no projeto;
- priorizar legibilidade, boa hierarquia, cores discretas e responsividade.

Trabalhe por fases: (1) inspecionar repositório, (2) estilos e navegação,
 (3) serviços DuckDB/dbt, (4) dashboard funcional, (5) páginas secundárias,
 (6) testes e documentação. Execute os comandos possíveis no ambiente
 e corrija erros encontrados. Não invente que um teste passou sem executá-lo.

Ao terminar, informe quais arquivos alterou, como iniciar o app,
 quais dados reais são mostrados e quais partes ainda dependem
 do pipeline/artefatos de teste.
```

---

## 23. Definição de pronto

**A implementação estará pronta quando a imagem de referência tiver virado uma interface Streamlit de verdade, com uma home limpa e dados confiáveis do projeto.** A estética é importante, mas o valor do DetectiveDB está em mostrar que o pipeline dbt transforma, documenta e **testa** os dados usados em uma investigação fictícia — incluindo o experimento demonstrável de falha/correção.
