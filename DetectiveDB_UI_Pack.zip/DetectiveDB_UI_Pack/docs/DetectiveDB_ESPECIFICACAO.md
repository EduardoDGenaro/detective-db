# DetectiveDB — Especificação e prompt de implementação

> **Instrução para a IDE (Copilot, Cursor ou agente de código):** use este documento como fonte de requisitos para criar a **base funcional** do DetectiveDB. Implemente por etapas, priorizando um pipeline dbt executável, dados consistentes, testes reproduzíveis e uma interface simples e utilizável. Não crie componentes fictícios nem apresente resultados de testes que não tenham sido realmente executados.

## 1. Visão geral

**DetectiveDB** é um laboratório de Engenharia de Dados com temática investigativa. Em um caso criminal **inteiramente fictício**, informações de suspeitos, depoimentos, câmeras, locais e evidências chegam em arquivos CSV. Um pipeline com **Python + DuckDB + dbt Core** carrega esses arquivos, transforma os dados, detecta problemas de qualidade e produz modelos analíticos. Uma UI em **Streamlit** permite explorar relações, cronologia, possíveis contradições e o estado da qualidade dos dados.

**A ideia central é ensinar Engenharia de Dados, não construir um jogo tradicional.** A investigação dá sentido às transformações SQL, aos testes e ao dashboard.

### Objetivo central

Demonstrar, de ponta a ponta:

1. Ingestão de pelo menos cinco arquivos CSV em tabelas brutas do DuckDB.
2. Transformações modulares em SQL por meio de modelos dbt.
3. Linhagem com `source()` e `ref()`.
4. Testes de qualidade com `unique`, `not_null`, `relationships`, `accepted_values` e ao menos um teste SQL personalizado.
5. Uma falha proposital de qualidade, seguida de correção e nova execução bem-sucedida.
6. Tabelas analíticas que apoiem uma investigação fictícia.
7. UI funcional, apresentando dados reais gerados pelo pipeline, nunca valores fixos de demonstração desconectados do banco.

## 2. Relação direta com o desafio original

| Exigência original | Implementação no DetectiveDB |
|---|---|
| Instalar `dbt-core` e `dbt-duckdb` no Colab | Manter dependências e notebook reprodutível |
| Criar arquivos `.sql` em `models/` | Criar modelos staging e marts de investigação |
| Limpar dados brutos | Padronizar nomes, tipos, horários e status |
| Criar testes `unique` e `not_null` | Validar IDs e campos críticos de fontes/modelos |
| Rodar `dbt run` e `dbt test` | Construir dimensões, fatos e executar a suíte |
| Inserir uma linha duplicada | Injetar evidência duplicada na camada `raw` |
| Demonstrar falha e correção | Capturar logs reais antes/depois e restaurar a fonte |
| Entregar notebook | Disponibilizar Colab com execução e evidências |

**Extensões além do desafio:** múltiplas fontes, `JOIN`, funções de janela, testes relacionais, teste personalizado, camada analítica, score explicável, documentação e UI.

## 3. Stack e ambiente

| Componente | Tecnologia | Responsabilidade |
|---|---|---|
| Transformação | dbt Core + dbt-duckdb | Modelos, dependências, testes e documentação |
| Banco analítico | DuckDB | Camadas bruta, staging e analítica |
| Orquestração local | Python | Ingestão e experimentos de qualidade |
| Fontes | CSV fictícios | Dados de investigação |
| Interface | Streamlit | Exploração interativa de resultados |
| Desenvolvimento | VS Code / IDE | Experiência principal de implementação |
| Demonstração portável | Google Colab | Notebook para executar ingestão e dbt sem instalar no PC |

**Limite de ambiente:** o pipeline precisa funcionar tanto localmente quanto no Colab. A UI Streamlit deve funcionar localmente; no Colab, priorizar demonstração dos dados e logs, sem exigir túnel público para servir a interface.

## 4. História e contexto do caso

**Caso 001 — O Relógio Parado.** Um objeto valioso desapareceu de uma mansão durante uma reunião noturna. Existem suspeitos, relatos de movimentação, câmeras em diferentes áreas e evidências coletadas. Parte dos dados está incompleta, duplicada ou contraditória.

A solução deve permitir descobrir **quais registros são confiáveis tecnicamente**, **quais informações se contradizem** e **quais pessoas merecem investigação adicional**. O sistema não deve afirmar culpabilidade com base exclusivamente em um score.

Criar entre **6 e 10 suspeitos**, **15 a 30 evidências**, **10 a 20 depoimentos**, **20 a 40 eventos de câmera** e **6 a 12 locais**, com dados determinísticos e coerentes entre si. Incluir ao menos uma contradição plausível, uma pista falsa e uma cadeia de evidências que recompense a exploração.

## 5. Estrutura de pastas

```text
detectivedb/
├── data/
│   ├── raw/
│   │   ├── suspects.csv
│   │   ├── evidence.csv
│   │   ├── testimonies.csv
│   │   ├── cameras.csv
│   │   └── locations.csv
│   └── detectivedb.duckdb              # gerado; não versionar
├── detective_dbt/
│   ├── dbt_project.yml
│   ├── profiles.yml                   # configuração local sem segredos
│   ├── models/
│   │   ├── sources.yml
│   │   ├── staging/
│   │   │   ├── stg_suspects.sql
│   │   │   ├── stg_evidence.sql
│   │   │   ├── stg_testimonies.sql
│   │   │   ├── stg_cameras.sql
│   │   │   └── stg_locations.sql
│   │   └── marts/
│   │       ├── dim_suspects.sql
│   │       ├── dim_locations.sql
│   │       ├── fct_evidence.sql
│   │       ├── fct_testimonies.sql
│   │       ├── fct_camera_events.sql
│   │       └── mart_case_summary.sql
│   ├── tests/
│   │   ├── assert_evidence_time_consistency.sql
│   │   └── assert_nonnegative_suspicion_score.sql
│   └── target/                       # gerado; não versionar
├── scripts/
│   ├── ingest_raw.py
│   ├── inject_bad_data.py
│   └── reset_demo.py
├── app/
│   ├── streamlit_app.py
│   ├── components/
│   └── styles/
├── notebooks/
│   └── detective_demo.ipynb
├── assets/
│   └── ui_reference.png               # opcional; imagem de referência fornecida separadamente
├── .gitignore
├── requirements.txt
└── README.md
```

Pode adicionar arquivos de suporte, mas preservar essa separação entre **ingestão**, **dbt** e **interface**. Evitar bibliotecas ou serviços desnecessários.

## 6. Contratos dos dados brutos

Todos os registros são fictícios. Usar chaves estáveis e horários ISO 8601, evitando depender da data de execução do notebook.

### `suspects.csv`

| Coluna | Tipo lógico | Observação |
|---|---|---|
| `suspect_id` | texto | ID estável, por exemplo `S001` |
| `suspect_name` | texto | Nome do suspeito |
| `age` | inteiro | Idade não negativa e plausível |
| `occupation` | texto | Profissão |
| `alibi` | texto | Relato resumido |
| `risk_level` | texto | `LOW`, `MEDIUM` ou `HIGH`; dado inicial, não conclusão |

### `evidence.csv`

| Coluna | Tipo lógico | Observação |
|---|---|---|
| `evidence_id` | texto | ID único, como `E001` |
| `suspect_id` | texto | Chave de suspeito (pode ser nula quando não identificado) |
| `location_id` | texto | Chave do local |
| `evidence_type` | texto | Categoria da evidência |
| `evidence_description` | texto | Descrição curta |
| `collected_at` | timestamp | Momento da coleta |
| `status` | texto | `COLLECTED`, `ANALYZED` ou `DISCARDED` |

### `testimonies.csv`

| Coluna | Tipo lógico | Observação |
|---|---|---|
| `testimony_id` | texto | ID único |
| `suspect_id` | texto | Suspeito do depoimento |
| `statement` | texto | Conteúdo do depoimento |
| `statement_time` | timestamp | Horário de registro |
| `claimed_location_id` | texto | Local onde a pessoa afirma ter estado |
| `claimed_event_time` | timestamp | Horário ao qual o álibi se refere |
| `consistency_flag` | booleano | Avaliação inicial (não é prova) |

### `cameras.csv`

| Coluna | Tipo lógico | Observação |
|---|---|---|
| `camera_event_id` | texto | ID único |
| `suspect_id` | texto | Suspeito identificado |
| `location_id` | texto | Local da câmera |
| `seen_at` | timestamp | Horário do evento |
| `camera_label` | texto | Nome/identificador da câmera |

### `locations.csv`

| Coluna | Tipo lógico | Observação |
|---|---|---|
| `location_id` | texto | ID único |
| `location_name` | texto | Nome do ambiente |
| `area_type` | texto | Ex.: `INDOOR`, `OUTDOOR` |
| `city_zone` | texto | Região fictícia |

**Importante:** para permitir detectar álibis conflitantes, não usar somente texto livre como entrada. Os campos `claimed_location_id` e `claimed_event_time` fornecem dados estruturados que podem ser comparados com os registros das câmeras.

## 7. Arquitetura de dados

```text
5 CSVs fictícios
      │
      ▼
Python (scripts/ingest_raw.py)
      │
      ▼
DuckDB / schema raw
      │
      ▼
dbt source() + modelos staging
      │
      ├── Testes de qualidade em fontes e modelos
      │
      ▼
dbt ref() + modelos marts
      │
      ├── dim_suspects
      ├── dim_locations
      ├── fct_evidence
      ├── fct_testimonies
      ├── fct_camera_events
      └── mart_case_summary
      │
      ▼
Streamlit: painel, suspeitos, evidências,
cronologia, contradições e qualidade
```

### Camada `raw`

Implementar `scripts/ingest_raw.py` usando `duckdb` em Python. Criar o schema `raw` e popular suas cinco tabelas a partir dos arquivos CSV. O script deve poder ser reexecutado sem gerar duplicidades involuntárias (por exemplo, recriando as tabelas da fonte original). Não eliminar registros problemáticos na ingestão: a camada bruta deve preservar o que foi recebido para possibilitar os testes.

### Camada `staging`

Um modelo SQL por fonte, sempre usando `{{ source('raw', '...') }}`. Padronizar os tipos, os valores e os nomes de colunas. Tratar dados incompletos explicitamente e documentar as regras de exclusão ou quarentena. **Não esconder silenciosamente um erro que deveria ser demonstrado pelos testes.**

### Camada `marts`

Usar `{{ ref('...') }}` para construir dimensões, fatos e visão consolidada. Exemplos de transformações: `JOIN`, `CASE WHEN`, `COUNT`, `COUNT(DISTINCT ...)`, `GROUP BY`, CTEs e funções de janela quando elas agregarem valor.

## 8. Regras analíticas

A tabela `mart_case_summary` deve conter, no mínimo:

| Coluna | Descrição |
|---|---|
| `suspect_id` | Chave do suspeito |
| `suspect_name` | Nome do suspeito |
| `evidence_count` | Total de evidências relacionadas |
| `testimony_count` | Total de depoimentos |
| `camera_events_count` | Total de registros de câmeras |
| `inconsistent_testimony_count` | Depoimentos marcados como inconsistentes |
| `alibi_camera_conflict_count` | Conflitos estruturados entre álibis e câmeras |
| `contradiction_flag` | Indica existência de conflito |
| `suspicion_score` | Indicador heurístico e explicável |

**Regra ilustrativa de score** (documentar e centralizar no SQL):

```text
suspicion_score =
    2 × evidence_count
  + 3 × inconsistent_testimony_count
  + 2 × suspicious_location_events
  + 4 × alibi_camera_conflict_count
```

O score é uma **heurística fictícia**, não uma probabilidade estatística de culpa. Não transformar diretamente `risk_level` em verdade ou usar um score alto como veredito.

**Contradição de álibi (MVP):** comparar `claimed_event_time` e `claimed_location_id` dos depoimentos com `seen_at` e `location_id` das câmeras do mesmo suspeito. Considerar conflito se houver registro em local diferente dentro de uma janela configurável (por exemplo, 5 minutos). Explicitar que é apenas uma possível contradição: câmeras, identificação e horários podem conter erros.

## 9. Qualidade de dados com dbt

### Testes prontos

Implementar em YAML com a sintaxe compatível com a versão instalada do dbt:

- `unique`: IDs de suspeitos, evidências, depoimentos, locais e eventos de câmera.
- `not_null`: chaves primárias e campos obrigatórios.
- `relationships`: integridade entre evidências/câmeras/depoimentos e suspeitos/locais, quando a chave estiver presente.
- `accepted_values`: `evidence.status`, `suspects.risk_level`, `locations.area_type`.

### Testes SQL personalizados

Criar em `detective_dbt/tests/`:

1. `assert_nonnegative_suspicion_score.sql`: retornar linhas com `suspicion_score < 0`.
2. `assert_evidence_time_consistency.sql`: retornar registros com anomalias temporais definidas claramente, como coleta anterior ao momento de ocorrência **quando esses dois campos estiverem disponíveis**. Caso a estrutura mínima não tenha horário de ocorrência, utilizar um teste equivalente verificável, por exemplo timestamps futuros em relação à data fixa do caso ou uma regra de validade acordada nos próprios dados; não referenciar colunas inexistentes.

**Lembrete:** um teste SQL genérico do dbt **passa quando a consulta não retorna linhas** e falha quando retorna registros que violam a regra.

### Onde testar as duplicidades

Para cumprir a demonstração sem mascarar problemas, aplicar ao menos o teste de unicidade de `evidence_id` **na fonte `raw.evidence`** (via `sources.yml`). Se a staging deduplicar registros, um teste somente sobre staging poderia passar mesmo com a fonte contaminada.

## 10. Experimento obrigatório: falha e correção

Implementar três scripts/ações reproduzíveis:

**A. Estado válido**

1. Executar `python scripts/ingest_raw.py`.
2. Executar `dbt run` e `dbt test`.
3. Salvar evidência de que os testes passaram.

**B. Estado inválido**

1. Executar `python scripts/inject_bad_data.py` para inserir uma cópia de evidência com o mesmo `evidence_id` na tabela `raw.evidence`.
2. Executar `dbt test`, preferencialmente selecionando também o teste da fonte.
3. Confirmar falha real de `unique` e registrar seu log/resultado.

**C. Recuperação**

1. Executar `python scripts/reset_demo.py` para restaurar o estado inicial, ou uma correção equivalente bem documentada.
2. Executar `dbt run` e `dbt test` novamente.
3. Confirmar que os testes passaram.

**Proibição:** não simular mensagens de erro, não usar screenshots fabricados e não marcar a demonstração como concluída sem comandos reais executados.

## 11. Comandos de desenvolvimento

Instalação de dependências:

```bash
pip install -r requirements.txt
```

O `requirements.txt` deve incluir ao menos `dbt-core`, `dbt-duckdb`, `duckdb`, `streamlit` e `pandas`, em versões mutuamente compatíveis e, de preferência, fixadas após validação.

Fluxo a partir da raiz:

```bash
python scripts/ingest_raw.py
cd detective_dbt
dbt debug --profiles-dir .
dbt run --profiles-dir .
dbt test --profiles-dir .
dbt docs generate --profiles-dir .
```

Para iniciar o Streamlit, a partir da raiz:

```bash
streamlit run app/streamlit_app.py
```

### Configuração de conexão

Criar `detective_dbt/profiles.yml` com um profile DuckDB usando o **mesmo arquivo** criado pela ingestão, por exemplo `../data/detectivedb.duckdb` quando os comandos dbt forem executados dentro de `detective_dbt/`. A aplicação Streamlit e os scripts devem apontar para esse mesmo arquivo com caminhos derivados da localização do repositório, não do diretório atual da shell.

Usar configurações de schema consistentes para que `source('raw', ...)` aponte ao schema `raw`, enquanto os modelos dbt sejam materializados nos schemas previstos no projeto. Incluir o banco `.duckdb` e a pasta `target/` no `.gitignore`.

## 12. Google Colab

Criar `notebooks/detective_demo.ipynb` com células que:

1. Instalem `dbt-core`, `dbt-duckdb`, `duckdb` e dependências necessárias.
2. Obtenham os arquivos do repositório (por upload ou clone configurável, sem URL inventada).
3. Executem a ingestão para DuckDB.
4. Rodem `dbt debug`, `dbt run` e `dbt test` no diretório correto.
5. Injetem o erro de duplicidade, capturem a falha esperada e expliquem o motivo.
6. Corrijam a fonte, executem novamente e exibam logs do sucesso.
7. Consultem `mart_case_summary` com Python/DuckDB e mostrem o resultado.

O notebook deve ser reexecutável em um ambiente limpo. Se houver caminhos diferentes no Colab, isolá-los em uma célula de configuração.

## 13. Interface Streamlit

### Direção visual

Uma mistura de **central de investigação, painel de inteligência e terminal analítico**, com aparência sóbria e contemporânea. Evitar a estética excessivamente caricata (papéis espalhados por toda a tela, fontes ilegíveis ou efeitos exagerados).

**Paleta sugerida:**

| Uso | Cor |
|---|---|
| Fundo | `#0B1017` |
| Cards | `#151D29` |
| Linhas/divisores | `#2A3443` |
| Texto principal | `#E7EDF5` |
| Texto secundário | `#99A7B8` |
| Destaque principal | `#D9A441` (âmbar) |
| Alerta | `#D95C5C` |
| Sucesso | `#57B89A` |
| Evidência informativa | `#6EABDE` |

### Layout

- Sidebar escura com marca **DetectiveDB**, número do caso e navegação.
- Cabeçalho com título do painel e subtítulo discreto.
- Cards compactos com KPIs.
- Área principal com cronologia, tabela de suspeitos e evidências.
- Painel de qualidade com resultados reais dos testes executados.
- Filtros por suspeito, local, período e status.
- Design responsivo possível dentro dos limites do Streamlit.

### Páginas ou abas

**1. Visão Geral**

- Total de suspeitos.
- Total de evidências.
- Total de depoimentos.
- Eventos de câmeras.
- Suspeitos com maior score (com aviso de heurística).

**2. Suspeitos**

- Tabela com nome, ocupação, álibi, evidências, eventos e score.
- Filtro de suspeitos.
- Visão de detalhe ao selecionar um suspeito.

**3. Evidências**

- Listagem filtrável por tipo, local, suspeito e status.
- Detalhes dos registros e suas conexões.

**4. Linha do Tempo e Contradições**

- Eventos ordenados cronologicamente.
- Sinalização de conflitos entre álibis e câmeras.
- Descrição explícita da regra que gerou cada alerta.

**5. Qualidade dos Dados**

- Status e contagem dos testes realmente executados.
- Resumo de falhas e possíveis linhas problemáticas.
- Indicação de quando os testes foram executados, caso disponível.
- Dados de `run_results.json` do dbt ou de um relatório persistido, sem apresentar status inventados.

**Comportamento sem dados:** se o banco ou as tabelas ainda não existirem, mostrar orientação amigável para executar ingestão e modelos, sem erro não tratado. Evitar que a UI mantenha conexão com DuckDB aberta enquanto um pipeline realiza escritas.

### Referência visual

O arquivo `assets/ui_reference.png` é **opcional** e pode ser preenchido com uma referência visual criada separadamente. A ausência dessa imagem não deve impedir a implementação. A UI deve seguir a descrição acima como fonte principal de layout e estilo.

## 14. Requisitos de implementação

- Código modular, legível, documentado quando necessário e com nomes consistentes.
- SQL em modelos dbt; não transferir transformações principais para pandas.
- Dados de exemplo determinísticos, com relações válidas no estado inicial.
- Testes e demonstração de falha realmente executáveis.
- Não usar credenciais, serviços pagos ou bancos externos.
- Evitar configuração desnecessária, Docker e autenticação no MVP.
- Garantir que consultas analíticas não multipliquem contagens por `JOIN` um-para-muitos; agregar por suspeito antes de juntar métricas quando necessário.
- Não misturar dados crus com a conclusão investigativa: distinguir **dados**, **alertas**, **heurísticas** e **interpretação**.

## 15. Entregáveis

1. Repositório com a estrutura de pastas definida.
2. Cinco CSVs fictícios coerentes.
3. Script de ingestão para DuckDB.
4. Projeto dbt funcional com staging e marts.
5. Arquivo YAML com testes e documentação.
6. Pelo menos dois testes SQL personalizados.
7. Scripts para injetar erro e restaurar estado válido.
8. Notebook do Colab mostrando execução, falha e correção.
9. Interface Streamlit com leitura real do banco.
10. `README.md` com instruções para instalação, execução, arquitetura, datasets e demonstração.

## 16. Critérios de aceitação

- [ ] `pip install -r requirements.txt` instala dependências compatíveis.
- [ ] A ingestão cria cinco tabelas no schema `raw` do DuckDB.
- [ ] `dbt debug` valida o profile e a conexão.
- [ ] `dbt run` constrói os modelos sem erro com dados válidos.
- [ ] `dbt test` passa com os dados válidos.
- [ ] A duplicação proposital faz o teste `unique` da fonte falhar.
- [ ] A correção faz os testes passarem novamente.
- [ ] `mart_case_summary` retorna uma linha por suspeito, sem contagens infladas.
- [ ] A UI abre e consulta as tabelas produzidas pelo dbt.
- [ ] O painel de qualidade distingue resultados reais de estados ainda não executados.
- [ ] O notebook documenta o antes e depois da falha.
- [ ] O README permite executar o MVP a partir de um clone limpo.

## 17. Ordem de implementação solicitada para a IDE

**Fase 1 — Fundação funcional (prioridade máxima)**

1. Criar pastas, dependências e configurações dbt/DuckDB.
2. Gerar os cinco CSVs consistentes.
3. Criar script de ingestão e as declarações de `source()`.
4. Implementar modelos staging e marts, incluindo o resumo final.
5. Criar testes e verificar a execução no ambiente disponível.

**Fase 2 — Experimento de qualidade**

1. Criar injeção de duplicidade e restauração.
2. Demonstrar falha real do teste e recuperação.
3. Montar notebook para execução em Colab.

**Fase 3 — Interface**

1. Construir estrutura Streamlit e identidade visual.
2. Exibir KPIs e tabelas do DuckDB.
3. Adicionar filtros, timeline, contradições e informações de qualidade.

**Fase 4 — Acabamento**

1. Revisar documentação e comandos.
2. Adicionar tratamento de erros e estados vazios.
3. Validar critérios de aceitação e registrar limitações restantes.

## 18. Prompt final para iniciar a IDE

> Atue como engenheiro de dados e desenvolvedor Python. Leia este documento inteiro e implemente a **Fase 1** do projeto **DetectiveDB**, priorizando um MVP executável de **dbt Core + DuckDB** com dados fictícios investigativos. Não apenas explique como fazer: crie os arquivos reais. Estruture o banco e os modelos com `source()` e `ref()`, insira dados coerentes, implemente testes de qualidade e gere a tabela `mart_case_summary`. Use SQL para transformações e Python apenas para ingestão, automações de demonstração e interface. Execute os comandos que estiverem disponíveis no ambiente e informe com precisão o que foi testado, o que passou, o que falhou e o que depende de execução futura. Depois prepare as bases das fases seguintes, sem adicionar complexidade desnecessária. Mantenha o foco no desafio original: **transformação modular e qualidade de dados com dbt Core + DuckDB**.

---

**Resumo:** a investigação é a temática; **o pipeline, os modelos dbt e os testes de qualidade são o verdadeiro produto**.
