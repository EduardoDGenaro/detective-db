# DetectiveDB — Pacote de UI

Este pacote contém os **PNGs da referência visual simplificada** e uma **especificação detalhada para uma IA implementar a interface** em Streamlit, conectada ao pipeline dbt Core + DuckDB.

## Comece aqui

1. Extraia o ZIP na raiz do projeto ou em uma pasta temporária.
2. Abra `DETECTIVEDB_UI_IMPLEMENTACAO.md` e `docs/DetectiveDB_ESPECIFICACAO.md`.
3. Mostre `reference/ui_reference_clean.png` à IA para ela compreender o visual desejado.
4. Copie `assets/` para a raiz do projeto e `app/styles/detectivedb_tokens.css` para `app/styles/`.
5. Peça à IDE: **"Leia DETECTIVEDB_UI_IMPLEMENTACAO.md, inspecione meu projeto e implemente a UI por fases, começando pelos estilos e pela conexão real com DuckDB."**

## Importante

A screenshot é **referência**, não um componente de dashboard; os PNGs são assets ilustrativos. Os KPIs, suspeitos, evidências e testes precisam ser lidos do DuckDB ou dos artefatos reais do dbt. O guia prevê estados vazios caso o pipeline ainda não tenha sido executado.
